#include <Arduino.h>
#include <Wire.h>
#include "pins.h"
#include "protocol.h"
#include "sensors.h"

static const int HMI_RX_PIN = 18;
static const int HMI_TX_PIN = 17;

HardwareSerial HMIserial(1);
MessageHandler handler(HMIserial, 't', 'h');

unsigned long lastDebugMs = 0;

void setup() {
    Serial.begin(9600);
    delay(1500);

    HMIserial.begin(9600, SERIAL_8N1, HMI_RX_PIN, HMI_TX_PIN);

    Wire.begin(PIN_HDC_SDA, PIN_HDC_SCL);
    Wire.setClock(100000);

    pinMode(PIN_RTD_ADC, INPUT);
    analogReadResolution(12);

    pinMode(PIN_STATUS_LED, OUTPUT);
    digitalWrite(PIN_STATUS_LED, LOW); // start OFF

    initSensors();

    Serial.println();
    Serial.println("Temp/Humidity subsystem ready");
    Serial.println("Serial = debug");
    Serial.println("Serial1 = HMI protocol");
    Serial.println();
}

void loop() {
    SensorData data = readSensors();

    handler.update(data);

    if (millis() - lastDebugMs >= 2000) {
        lastDebugMs = millis();

        Serial.println("----- Sensor Debug -----");
        Serial.print("Temperature: ");
        Serial.print(data.temperatureC, 2);
        Serial.println(" C");

        Serial.print("Humidity:    ");
        Serial.print(data.humidity, 2);
        Serial.println(" %");

        Serial.print("RTD Voltage: ");
        Serial.print(data.rtdVoltage, 4);
        Serial.println(" V");

        Serial.print("PT1000 Ohms: ");
        Serial.println(data.rtdResistance, 2);

        Serial.print("PT1000 Temp: ");
        Serial.print(data.rtdTemperatureC, 2);
        Serial.println(" C");
        Serial.println();
    }

    delay(10);
}