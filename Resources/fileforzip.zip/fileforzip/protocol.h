#pragma once
#include <Arduino.h>
#include "sensors.h"

enum class TempUnit {
  Celsius,
  Fahrenheit
};

class MessageHandler {
public:
  MessageHandler(Stream& serial, char selfId, char hmiId);
  void update(const SensorData& data);
  TempUnit getUnit() const;

private:
  Stream& _serial;
  char _selfId;
  char _hmiId;
  TempUnit _unit = TempUnit::Celsius;

  String _rxBuffer;

  void processRawPacket(const String& packet, const SensorData& data);
  bool parseEnvelope(const String& packet, char& src, char& dst, String& payload);
  void forwardRawPacket(const String& packet);

  void handlePayload(char src, char dst, const String& payload, const SensorData& data);

  void handleStart(const String& payload);
  void handleChangeUnit(char src, const String& payload);
  void handleRequestTemp(char src, const String& payload, const SensorData& data);
  void handleRequestHumidity(char src, const String& payload, const SensorData& data);
  
  void sendTemperature(char dest, float temperatureC);
  void sendHumidity(char dest, float humidity);
  void sendPacket(char dest, const String& payload);

  float convertTemperature(float tempC) const;
  char currentUnitChar() const;
};