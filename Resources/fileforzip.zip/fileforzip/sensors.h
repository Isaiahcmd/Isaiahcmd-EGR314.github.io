#pragma once

struct SensorData {
    float temperatureC;
    float humidity;
    float rtdVoltage;
    float rtdResistance;
    float rtdTemperatureC;
};

void initSensors();
SensorData readSensors();