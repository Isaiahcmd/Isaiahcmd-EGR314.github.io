#include "protocol.h"
#include "pins.h"

MessageHandler::MessageHandler(Stream& serial, char selfId, char hmiId)
    : _serial(serial), _selfId(selfId), _hmiId(hmiId) {}

TempUnit MessageHandler::getUnit() const {
  return _unit;
}

void MessageHandler::update(const SensorData& data) {
  while (_serial.available()) {
    char c = static_cast<char>(_serial.read());

    Serial.print("RX CHAR: ");
    Serial.println(c);

    _rxBuffer += c;

    // keep buffer bounded
    if (_rxBuffer.length() > 256) {
      _rxBuffer.remove(0, _rxBuffer.length() - 256);
    }

    int startIdx = _rxBuffer.indexOf("AZ");
    int endIdx = _rxBuffer.indexOf("YB", startIdx >= 0 ? startIdx : 0);

    while (startIdx >= 0 && endIdx >= 0 && endIdx > startIdx) {
      String packet = _rxBuffer.substring(startIdx, endIdx + 2);
      _rxBuffer.remove(0, endIdx + 2);

      Serial.print("FULL PACKET: ");
      Serial.println(packet);

      processRawPacket(packet, data);

      startIdx = _rxBuffer.indexOf("AZ");
      endIdx = _rxBuffer.indexOf("YB", startIdx >= 0 ? startIdx : 0);
    }
  }
}

void MessageHandler::processRawPacket(const String& packet, const SensorData& data) {
  char src = '\0';
  char dst = '\0';
  String payload;

  if (!parseEnvelope(packet, src, dst, payload)) {
    Serial.println("parseEnvelope failed");
    return;
  }

  Serial.print("Parsed src=");
  Serial.print(src);
  Serial.print(" dst=");
  Serial.print(dst);
  Serial.print(" payload=");
  Serial.println(payload);

  // ignore packets that originated from this node
  if (src == _selfId) {
    Serial.println("Ignoring packet from self");
    return;
  }

  // broadcast packet: handle locally and pass on
  if (dst == 'X') {
    Serial.println("Broadcast packet received");
    handlePayload(src, dst, payload, data);
    return;
  }

  // packet for this node
  if (dst == _selfId) {
    Serial.println("Packet is for me");
    handlePayload(src, dst, payload, data);
    return;
  }

  // valid packet not meant for us -> forward unchanged
  Serial.println("Packet not for me, forwarding...");
  forwardRawPacket(packet);
}

bool MessageHandler::parseEnvelope(const String& packet, char& src, char& dst, String& payload) {
  if (!packet.startsWith("AZ")) return false;
  if (!packet.endsWith("YB")) return false;
  if (packet.length() < 6) return false;

  src = packet.charAt(2);
  dst = packet.charAt(3);
  payload = packet.substring(4, packet.length() - 2);

  return true;
}

void MessageHandler::handlePayload(char src, char dst, const String& payload, const SensorData& data) {
  // teammate broadcast format: DEST='X', payload="ST:S:Start;"
  if (payload == "ST:S:Start;") {
    handleStart(payload);
    return;
  }

  if (payload.startsWith("CU:")) {
    handleChangeUnit(src, payload);
    return;
  }

  // teammate HMI sends TR:S:Read;
  if (payload.startsWith("TR:")) {
    handleRequestTemp(src, payload, data);
    return;
  }

  // teammate HMI sends HR:S:Read;
  if (payload.startsWith("HR:")) {
    handleRequestHumidity(src, payload, data);
    return;
  }

  Serial.println("Unknown payload, ignoring");
}

void MessageHandler::forwardRawPacket(const String& packet) {
  Serial.print("FORWARDING PACKET: ");
  Serial.println(packet);

  _serial.print(packet);
  _serial.print("\r\n");
}

void MessageHandler::handleStart(const String& payload) {
  Serial.println("Received start packet");

  digitalWrite(PIN_STATUS_LED, HIGH);

  // pass on the broadcast in teammate-compatible format
  sendPacket('X', "ST:S:Start;");
}

void MessageHandler::handleChangeUnit(char src, const String& payload) {
  int first = payload.indexOf(':');
  int second = payload.indexOf(':', first + 1);
  int term = payload.indexOf(';');

  if (first < 0 || second < 0 || term < 0) return;

  String typeId = payload.substring(first + 1, second);
  String value = payload.substring(second + 1, term);

  if (typeId != "S" || value.length() != 1) return;

  char requested = value.charAt(0);

  if (requested == 'C') {
    _unit = TempUnit::Celsius;
    Serial.println("Unit changed to Celsius");
  } else if (requested == 'F') {
    _unit = TempUnit::Fahrenheit;
    Serial.println("Unit changed to Fahrenheit");
  }
}

void MessageHandler::handleRequestTemp(char src, const String& payload, const SensorData& data) {
  int first = payload.indexOf(':');
  int second = payload.indexOf(':', first + 1);
  int term = payload.indexOf(';');

  if (first < 0 || second < 0 || term < 0) return;

  String typeId = payload.substring(first + 1, second);
  String value = payload.substring(second + 1, term);

  // teammate format: TR:S:Read;
  // allow legacy TR:S:T; too, for easier testing
  if (typeId == "S" && (value == "Read" || value == "T")) {
    Serial.println("Sending temperature reply");
    sendTemperature(src, data.rtdTemperatureC);
  }
}

void MessageHandler::handleRequestHumidity(char src, const String& payload, const SensorData& data) {
  int first = payload.indexOf(':');
  int second = payload.indexOf(':', first + 1);
  int term = payload.indexOf(';');

  if (first < 0 || second < 0 || term < 0) return;

  String typeId = payload.substring(first + 1, second);
  String value = payload.substring(second + 1, term);

  // teammate format: HR:S:Read;
  // allow legacy HR:S:H; too
  if (typeId == "S" && (value == "Read" || value == "H")) {
    Serial.println("Sending humidity reply");
    sendHumidity(src, data.humidity);
  }
}

void MessageHandler::sendTemperature(char dest, float temperatureC) {
  float outTemp = convertTemperature(temperatureC);
  char unit = currentUnitChar();

  String payload = "TV:F:" + String(outTemp, 2) + ";TT:S:" + String(unit) + ";";
  sendPacket(dest, payload);
}

void MessageHandler::sendHumidity(char dest, float humidity) {
  // teammate HMI handles HV:
  String payload = "HV:F:" + String(humidity, 2) + ";";
  sendPacket(dest, payload);
}

void MessageHandler::sendPacket(char dest, const String& payload) {
  Serial.print("TX PACKET: AZ");
  Serial.print(_selfId);
  Serial.print(dest);
  Serial.print(payload);
  Serial.println("YB");

  _serial.print("AZ");
  _serial.print(_selfId);
  _serial.print(dest);
  _serial.print(payload);
  _serial.print("YB");
  _serial.print("\r\n");
}

float MessageHandler::convertTemperature(float tempC) const {
  if (_unit == TempUnit::Fahrenheit) {
    return tempC * 9.0f / 5.0f + 32.0f;
  }
  return tempC;
}

char MessageHandler::currentUnitChar() const {
  return (_unit == TempUnit::Fahrenheit) ? 'F' : 'C';
}