#include <Arduino.h>
#include <Wire.h>
#include <math.h>
#include "pins.h"
#include "sensors.h"

static const uint8_t HDC2080_ADDR = 0x40;
static const uint8_t REG_TEMP_L = 0x00;
static const uint8_t REG_HUM_L  = 0x02;
static const uint8_t REG_CONFIG = 0x0E;
static const uint8_t REG_MEAS   = 0x0F;

static constexpr float HDC_TEMP_OFFSET = -2.0f;

static bool writeReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(HDC2080_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return (Wire.endTransmission() == 0);
}

static bool readBytes(uint8_t reg, uint8_t* buf, uint8_t len) {
  Wire.beginTransmission(HDC2080_ADDR);
  Wire.write(reg);

  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)HDC2080_ADDR, (int)len) != len) return false;

  for (uint8_t i = 0; i < len; i++) {
    buf[i] = Wire.read();
  }

  return true;
}

// Divider:
// RTD_VREF -> PT1000 -> node(V_RTD) -> RTD_R_FIXED -> GND
//
// V_RTD = RTD_VREF * RTD_R_FIXED / (R_PT1000 + RTD_R_FIXED)
// R_PT1000 = RTD_R_FIXED * (RTD_VREF / V_RTD - 1)
static float readRtdVoltage() {
  uint16_t raw = analogRead(PIN_RTD_ADC);
  return raw * (3.3f / 4095.0f);
}

static float pt1000ResistanceFromVoltage(float vRtd) {
  if (vRtd <= 0.001f || vRtd >= RTD_VREF) return NAN;
  return RTD_R_FIXED * ((RTD_VREF / vRtd) - 1.0f);
}

// Positive-temperature inverse Callendar–Van Dusen
static float pt1000TempC_FromResistance(float r) {
  const float A = 3.9083e-3f;
  const float B = -5.775e-7f;

  float ratio = r / PT1000_R0;
  float disc = A * A - 4.0f * B * (1.0f - ratio);

  if (disc < 0.0f) return NAN;

  return (-A + sqrtf(disc)) / (2.0f * B);
}

void initSensors() {
  writeReg(REG_CONFIG, 0x00);
}

SensorData readSensors() {
  SensorData data{};

  data.temperatureC = NAN;
  data.humidity = NAN;
  data.rtdVoltage = NAN;
  data.rtdResistance = NAN;
  data.rtdTemperatureC = NAN;

  // HDC2080
  writeReg(REG_MEAS, 0x01);
  delay(20);

  uint8_t raw[4];
  if (readBytes(REG_TEMP_L, raw, 4)) {
    uint16_t temp_raw = (raw[1] << 8) | raw[0];
    uint16_t hum_raw  = (raw[3] << 8) | raw[2];

    data.temperatureC = (temp_raw / 65536.0f) * 165.0f - 40.0f + HDC_TEMP_OFFSET;
    data.humidity = (hum_raw / 65536.0f) * 100.0f;
  }

  // PT1000
  data.rtdVoltage = readRtdVoltage();
  data.rtdResistance = pt1000ResistanceFromVoltage(data.rtdVoltage);

  // Temporary calibration offset, okay for now while testing
  float rtdCal = data.rtdResistance - 281.0f;
  data.rtdTemperatureC = pt1000TempC_FromResistance(rtdCal);

  return data;
}