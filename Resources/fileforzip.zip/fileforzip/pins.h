#pragma once

// HDC2080
static constexpr int PIN_HDC_SDA  = 8;
static constexpr int PIN_HDC_SCL  = 9;
static constexpr int PIN_HDC_DRDY = 7;

// LED
static constexpr int PIN_STATUS_LED = 35;

// PT1000 analog output
static constexpr int PIN_RTD_ADC  = 6;

// Divider values
static constexpr float RTD_VREF    = 2.5f;
static constexpr float RTD_R_FIXED = 10000.0f;
static constexpr float PT1000_R0   = 1000.0f;